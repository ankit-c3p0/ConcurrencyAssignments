package Thread;

import java.util.concurrent.TimeUnit;
//@Mrinmoy Pradhan
class CountDownLatchCustom{
	 
    private int count;
    ThreadLocal<Long> inTime=new ThreadLocal<>();
    ThreadLocal<Long> outTime=new ThreadLocal<>();

    public CountDownLatchCustom(int count) {
           this.count=count;
    }
 

    public synchronized void await() throws InterruptedException {
           if(count>0)
                  this.wait();
    }
    //Time is fixed as Millisec.
    public synchronized boolean await(long time,TimeUnit unit) throws InterruptedException {
    	boolean flag=false;
    	System.out.println("count "+count);
        if(count>0)
        {
        	inTime.set(System.currentTimeMillis());
        
               this.wait(time);
               
             outTime.set(System.currentTimeMillis());
             System.out.println(outTime.get()-inTime.get());
             /*if (count>0)
        	    {
        	    }*/
               if((outTime.get()-inTime.get())<time)
               {
            	   flag=true;
               }
        }
        else
        {
        	flag=true;
        }
        return flag;
 }
    public synchronized void countDown() {

           count--;
           
           if(count == 0)
                  this.notifyAll();
    }
    
    public synchronized long getCount() {
    	
    	return this.count;
    }
}
    