
package Thread;

import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
public class CyclicB {

	
	public static void main(String args[]) throws InterruptedException
	{
		CustomCylclicBarrier lat=new CustomCylclicBarrier(2);
		Cyclic f=new Cyclic(lat);
		Cyclick f1=new Cyclick(lat);
		Cyclick f2=new Cyclick(lat);
		
		f.start();
		
		Thread.sleep(3000);
		lat.reset();
		System.out.println(lat.getNumberWaiting()+": "+lat.getParties());
		//f1.interrupt();
		f1.start();
		f2.start();
		//lat.reset();
		//Thread.sleep(2000);
		
		System.out.println(lat.getNumberWaiting()+": "+lat.getParties());
		//lat.reset();
		/*Cyclic f2=new Cyclic(lat);
		Cyclick f3=new Cyclick(lat);
		
		f2.start();
		f3.start();*/
		//f.interrupt();
		
	}
}
class Cyclic extends Thread
{
	CustomCylclicBarrier lat;
	Cyclic(CustomCylclicBarrier lat)
	{
		this.lat=lat;
	}
	public void run()
	{
		System.out.println(Thread.currentThread().getName()+"  Start "+lat.getNumberWaiting());
		try {
			lat.await(2000,TimeUnit.SECONDS);;
			//lat.await();
		} catch (InterruptedException | BrokenBarrierException | TimeoutException e) {
			// TODO Auto-generated catch block
			//System.out.println(Thread.currentThread().getName()+lat.getCount());
			System.out.println(Thread.currentThread().getName()+"EXCEPTION 1 "+e.toString() );
		}
		System.out.println(Thread.currentThread().getName()+" End");
	}
}

class Cyclick extends Thread
{
	CustomCylclicBarrier lat;
	Cyclick(CustomCylclicBarrier lat)
	{
		this.lat=lat;
	}
	public void run()
	{
		System.out.println(Thread.currentThread().getName()+"  Start "+lat.getNumberWaiting());
		try {
			//lat.await(2,TimeUnit.SECONDS);;
			lat.await(2000,TimeUnit.SECONDS);;
		} catch (InterruptedException | BrokenBarrierException | TimeoutException e/* | TimeoutException e*/) {
			// TODO Auto-generated catch block
			System.out.println(Thread.currentThread().getName()+"EXCEPTION 2 " +e.toString());
		}
		System.out.println(Thread.currentThread().getName()+" End ");
	}
}
