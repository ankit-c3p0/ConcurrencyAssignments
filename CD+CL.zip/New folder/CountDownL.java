package Thread;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class CountDownL {

	
	public static void main(String args[]) throws InterruptedException
	{
		CountDownLatchCustom lat=new CountDownLatchCustom(2);
		Flow f=new Flow(lat);
		//lat.countDown();
		//lat.countDown();
		f.start();
		//Thread.currentThread().sleep(2000);
		//lat.countDown();
		Flow f1=new Flow(lat);
		f1.start();
		
		f.interrupt();
		Thread.currentThread().sleep(2000);
		lat.countDown();
		lat.countDown();
		Flow f2=new Flow(lat);
		f2.start();
		//f1.interrupt();
		
	}
}
class Flow extends Thread
{
	CountDownLatchCustom lat;
	Flow(CountDownLatchCustom lat)
	{
		this.lat=lat;
	}
	public void run()
	{
		System.out.println(Thread.currentThread().getName()+" Start");
		try {
			lat.await();
			//System.out.println(lat.await(4000,TimeUnit.MILLISECONDS));
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			System.out.println("Exception "+e.toString()+" "+Thread.currentThread().getName()+" Count "+lat.getCount());
		}
		System.out.println(Thread.currentThread().getName()+" End");
	}
}