package Thread;

import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

//@Mrinmoy pradhan
public class CustomCylclicBarrier {

	private long parties;
	private long totalParties;
	private boolean isBroken=false;
	private boolean isInterupted=false;
	private boolean isTimeOut=false;
	ThreadLocal<Long> inTime=new ThreadLocal<>();
    ThreadLocal<Long> outTime=new ThreadLocal<>();
	
	
	public CustomCylclicBarrier(long parties)
	{
		this.parties=parties;
		this.totalParties=parties;
	}
	public synchronized void await() throws InterruptedException, BrokenBarrierException {
		parties--;
        if (parties>0 && !isInterupted)
        {
        	try
        	{
               this.wait();
        	}
        	catch(InterruptedException e)
        	{
        		isInterupted=true;
        		this.notifyAll();
        	}
        }
        else
        {
        	parties=totalParties;
        	this.notifyAll();
        }
        
        if(isBroken || isTimeOut)
        {
        	
        	parties=totalParties;
        	throw new BrokenBarrierException();
        }
        else if(isInterupted)
        {
        	
        	parties=totalParties;
        	throw new InterruptedException();
        }
        
 }
	
 //Time is fixed as Millisec.
 public synchronized boolean await(long time,TimeUnit unit) throws InterruptedException, BrokenBarrierException,TimeoutException{
	 
	 parties--;
     if (parties>0 && !isInterupted)
     {
     	try
     	{
     		inTime.set(System.currentTimeMillis());
            this.wait(time);
       	    outTime.set(System.currentTimeMillis());
       	    System.out.println(outTime.get()-inTime.get());
       	    
       	    /*if (parties>0 && !isTimeOut)
       	    {
       	    }*/
       	    if((outTime.get()-inTime.get())>=time && !isTimeOut )
       	    {
       	    	isTimeOut=true;
       	    	this.notifyAll();
       	    	throw new TimeoutException();
       	    }
     	}
     	catch(InterruptedException e)
     	{
     		isInterupted=true;
     		this.notifyAll();
     	} 
     }
     else
     {
     	parties=totalParties;
     	this.notifyAll();
     }
     
     if(isBroken || isTimeOut)
     {
     	
     	parties=totalParties;
     	throw new BrokenBarrierException();
     }
     else if(isInterupted)
     {
     	
     	parties=totalParties;
     	throw new InterruptedException();
     }
     

	 
	 
	return true;
 }
 
	public synchronized void reset()
	{
		if(parties<totalParties)
		{
		isBroken=true;
		}
		isInterupted=false;
		isTimeOut=false;
		this.notifyAll();
		
	}
 
 public synchronized long getNumberWaiting()
 {
	 return totalParties-parties;
 }
 public synchronized boolean isBroken()
 {
	 return isInterupted && isTimeOut;
 }
 public synchronized long getParties() {
 	
 	return this.totalParties;
 }
}
