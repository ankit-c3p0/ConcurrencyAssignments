package org.gs;

public class LongPalindromicSubstring_1 {
	
	static String str = "aabaad"; //"aacabacd";
	
	static String longestPalindromicSubstring(String str) {
		
		char[] arr = str.toCharArray();
		int len = str.length();
		boolean[][] flags = new boolean[len-1][len-1];
		
		int maxlen =0;
		//handling single case
		for(int i=0; i< len-1; i++) {
			flags[i][i] = true;
			maxlen = 1;
		}
		
		for(int i=0; i<len-1; i++) {
			if(arr[i] == arr[i+1]) {
				flags[i][i+1] = true;
				maxlen = 2;
			}
		}
		
		int fp=0;
		int k=2;
		while(k<len) {
			
			for(int j=0;j<len-k;j++) {
				if(arr[j] == arr[j+k] && flags[j+1][j+k-1]) {
					flags[j][j+k] = true;
					maxlen = k+1;
					fp =j;
				}
			}
			k++;
		}
		return str.substring(fp, fp+maxlen);
	}
	
	public static void main(String[] args) {
		
		System.out.println(longestPalindromicSubstring(str));
	}
}
