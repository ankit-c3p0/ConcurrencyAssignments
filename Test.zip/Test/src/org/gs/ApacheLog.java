package org.gs;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;


public class ApacheLog {

	public static void main(String[] args) {
		
		String str1 = "10.0.0.2 - frank [10/Oct/2000:13:55:36" + " -0700] \"GET /apache_pb.gif HTTP/1.0\" 200 2326 "
				+ "\"http://www.example.com/start.html\" \"Mozilla/4.08 " + "[en] (Win98; I ;Nav)\"";
		
		String str2 = "10.0.0.1- frank [10/Oct/2000:13:55" + ":36 -0700] \"GET /apache_pb.gif HTTP/1.0\" 200 2326 "
				+ "\"http://www.example.com/start.html\" \"Mozilla/4.08 " + "[en] (Win98; I ;Nav)\"";
		
		String str3 = "10.0.2.1 - frank [10/Oct/2000:13:55" + ":36 -0700] \"GET /apache_pb.gif HTTP/1.0\" 200 2326 "
				+ "\"http://www.example.com/start.html\" \"Mozilla/4.08 " + "[en] (Win98; I ;Nav)\"";
		
		
		System.out.println(getTopIp(new String[] {str1, str2, str3}));
		
	}
	
	static String getTopIp(String[] lines) {
		
		List<String> list = new ArrayList<>();
		for(int i=0; i<lines.length; i++) {
			list.add(lines[i].split("-")[0].trim());
		}
		
		Collections.sort(list, new IPAddressComparator());
		
		/*for(String str: list) {
			System.out.println(str);
		}*/
		return list.get(0);
	}
	


	static class IPAddressComparator implements Comparator<String> {
		
		
		@Override
		public int compare(String s1, String s2) {

			String[] ip1 = s1.split("\\.");
			String[] ip2 = s2.split("\\.");
			
			String upIp1 = String.format("%3s.%3s.%3s.%3s", ip1[0], ip1[1], ip1[2], ip1[3]);
			String upIp2 = String.format("%3s.%3s.%3s.%3s", ip2[0], ip2[1], ip2[2], ip2[3]);
			
			return upIp2.compareTo(upIp1);
		}
	}
	
}
