package org.gs;

import java.util.Arrays;

public class GetPairForGivenSum {

	public static void getPairForGivenSum(int arr[], int sum) {
		
		Arrays.sort(arr);
		
		int start = 0;
		int end = arr.length-1;
		while(start < end) {
			int actSum = arr[start] + arr[end];
			if(actSum == sum) {
				System.out.println("The pair is: " + arr[start] + "," + arr[end]);
				start++;
				end--;
			} else if(actSum<sum) 
				start ++;
			else
				end --;
		}
	}
	
	public static void main(String[] args) {
		
		int arr[] = {2, 4, 7, 5, 9, 10, -1};
		getPairForGivenSum(arr, 9);
		
		
	}
}
