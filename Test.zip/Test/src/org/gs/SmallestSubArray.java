package org.gs;

public class SmallestSubArray {

	static void smallestSubArrayWithSum(int[] arr, int sum) {

		int start = 0;
		int min_len = arr.length + 1;
		int curr_sum=0;
		for (int i = 0; i < arr.length; i++) {

			int expSum = 0;
			int index = i;
			int len = 0;
			if (expSum > arr[i]) {
				System.out.println(arr[i]);
				return;
			}
			for (int j = i; j < arr.length; j++) {
				expSum += arr[j];
				len++;
				if (expSum > sum && len < min_len) {
					min_len = len;
					start=index;
					curr_sum=expSum;
					System.out.println(index + "," + min_len);
				}
			}
		}
		if(curr_sum<sum && min_len>arr.length) {
			System.out.println("Invalid");
			return;
		}
		for (int k = start; k < min_len + 1; k++)
			System.out.println(arr[k]);
	}

	public static void main(String[] args) {
		smallestSubArrayWithSum(new int[] { 1, 10, 5, 2, 7 }, 26);
	}
}
