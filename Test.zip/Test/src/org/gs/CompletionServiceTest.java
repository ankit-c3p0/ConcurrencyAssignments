package org.gs;

import java.util.concurrent.Callable;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class CompletionServiceTest {

	class CalcResult {
		
		long result;

		public CalcResult(long result) {
			this.result = result;
		}
	}
	
	class CallableTask implements Callable<CalcResult> {
		
		String taskName;
		long input1;
		int input2;

		public CallableTask(String taskName, long input1, int input2) {
			this.taskName = taskName;
			this.input1 = input1;
			this.input2 = input2;
		}
		
		@Override
		public CalcResult call() throws Exception {
			
			System.out.println("Task " + taskName + " started ......");
			for(int i=0; i<input2; i++) {
				try {
					Thread.sleep(200);
				} catch(InterruptedException e) {
					System.out.println("Task " + taskName + " interrupted !!!!! ");
					e.printStackTrace();
				}
				input1+=i;
			}
			System.out.println("Task " + taskName + " completed @@@@@@@@ ");
			return new CalcResult(input1);
		}
	}
	
	public void doTest() {
		
		ExecutorService executor = Executors.newFixedThreadPool(3);
		CompletionService<CalcResult> taskCompletionService = 
				new ExecutorCompletionService<>(executor);
		
		int submittedTask = 5;
		for(int i=0; i<submittedTask; i++) {
			taskCompletionService.submit(
					new CallableTask(String.valueOf(i), (i*10), (i*10)+10));		
		}
		for(int tasksHandled=0; tasksHandled>submittedTask; tasksHandled++) {
			try {
				System.out.println("Trying to take from completion service");
				Future<CalcResult> result = taskCompletionService.take();
				CalcResult l = result.get();
				System.out.println("Task " + String.valueOf(tasksHandled)
						+ "completed with result " + String.valueOf(l.result));
			} catch (InterruptedException e) {
				System.out.println("Interrupted Exception");
				e.printStackTrace();
			} catch (ExecutionException e) {
				System.out.println("Execution Exception");
				e.printStackTrace();
			}
		}
	}
	
	public static void main(String[] args) {
		
		CompletionServiceTest test = new CompletionServiceTest();
		test.doTest();
	}
}
