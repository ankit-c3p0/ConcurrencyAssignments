package org.gs;

public class MatrixSpiralPrint {

	public static void main(String[] args) {
		
		int[][] matrix = {
				   {1,  2,  3,  4,  5},
				   {6,  7,  8,  9,  10},
				   {11, 12, 13, 14, 15},
				   {16, 17, 18, 19, 20},
				   {21, 22, 23, 24, 25}
				  };
		
		printMatrixSpiral(matrix);
	}

	static void printMatrixSpiral(int[][] matrix) {
	
		int rowStart = 0;
		int rowLength = matrix.length-1;
		
		int colStart = 0;
		int colLength = matrix.length-1;
		
		while(rowStart<=rowLength && colStart<=colLength) {
			
			for(int i=rowStart; i<=colLength;i++) {
				System.out.print(matrix[rowStart][i] + " ");
			}

			for(int i=rowStart+1; i<=rowLength;i++) {
				System.out.print(matrix[i][colLength] + " ");
			}
			if(rowStart+1 <= rowLength) {
				for(int i=colLength-1; i>=colStart;i--) {
					System.out.print(matrix[rowLength][i] + " ");
				}	
			}
			if(colStart+1 <= colLength) {
				for(int i=rowLength-1; i>rowStart;i--) {
					System.out.print(matrix[i][colStart] + " ");
				}	
			}
			
			rowStart++;
			rowLength--;
			colStart++;
			colLength--;
		}
	}
}
