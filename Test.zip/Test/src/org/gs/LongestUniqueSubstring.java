package org.gs;

import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;

public class LongestUniqueSubstring {

	/*static String getLongestUniqueSubString(String str) {
		
		LinkedHashSet<Character> _set = new LinkedHashSet<>();
		int start = 0;
		for(int i=0; i<str.length(); i++) {

			char c = str.charAt(i);
			if(!_set.contains(c)) {
				_set.add(c);
			} else {
				 while(start<i && str.charAt(i) != c) {
					 _set.remove(str.charAt(start));
					 start++;
				 }
				
			}
		}
		StringBuilder sb = new StringBuilder();
		for(Character ch: _set) {
			sb.append(ch);
		}
		return sb.toString();
	}*/
	
	static String getLongestUniqueSubString(String str) {
	
		char[] c =str.toCharArray();
		int maxlen = 0;
		int subStringIndex = 0;
		Map<Character, Integer> map = new HashMap<>();
		
		for(int index=0; index<c.length;) {
			
			int startIndex = index;
			int currLen = 0;
			
			while(index < c.length && !map.containsKey(c[index])) {
				map.put(c[index], index);
				index++;
				currLen++;
			}
			
			if(currLen>maxlen){
				maxlen = currLen;
				subStringIndex = startIndex;
			}
			
			if(index<c.length) 
				index = map.get(c[index])+1;
			map.clear();
		}
		
		return str.substring(subStringIndex, subStringIndex+maxlen);
	}
	
	
	public static void main(String[] args) {
	
		System.out.println(getLongestUniqueSubString("aaabcbdeaffabckzyui"));
	}
}
