package org.gs;

public class LongestPalindromicSubstring {

	public static void main(String[] args) {
		String input = "aacbccabac";
		char[] arr = input.toCharArray();
		int len = input.length();
		boolean[][] a = new boolean[len][len];

		int maxlength = 0;
		// for all single character1222222`
		for (int i = 0; i < len; i++) {
			a[i][i] = true;
			maxlength = 1;
		}

		// for all 2 character pairs
		for (int i = 0; i < len - 1; i++) {
			if (arr[i] == arr[i + 1]) { //(a[i][i] == a[i][i + 1]) {
				a[i][i + 1] = true;
				maxlength = 2;
			}

		}

		// for all other case; len>2
		int fp = 0;

		int k = 2;
		while (k < len) {
			for (int j = 0; j < len - k; j++) {
				if ((arr[j] == arr[j + k]) && a[j + 1][j + k - 1]) {
					a[j][j + k] = true;
					maxlength = k + 1;
					fp = j;
				}
			}
			k++;
		}
		
		for(int i=0; i<a[0].length-1; i++) {
			for(int j=0; j<a[0].length-1; j++){
				System.out.print(a[i][j] + " ");
			}
			System.out.println("");
		}
		
		System.out.println("fp : " + fp + " maxlength : " + maxlength);
		System.out.println(input.substring(fp, fp + maxlength));

	}

}
