package org.gs;

import java.util.ArrayList;
import java.util.LinkedHashMap;

class Solution {
	  public static void main(String[] args) {
	    ArrayList<String> strings = new ArrayList<String>();
	    strings.add("Hello, World!");
	    strings.add("Welcome to CoderPad.");
	    strings.add("This pad is running Java 8.");

	    for (String string : strings) {
	      System.out.println(string);
	    }
	    
	    String[][] scores={{"Bobby","123"},
	{"Alia","-678"},
	{"Bobby","100"},
	{"Alex","223"},
	{"Alex","-23"},
	{"Bobby","723"}
	};
	    
	    
	    String[][] scores1={{"Prateek","123"},
	    		{"Prateek","-678"},
	    		{"Ankit","100"},
	    		{"Ankit","223"},
	    		{"Tanvir","-23"},
	    		{"Prateek","723"}
	    		};
	    
	    System.out.println(getAverageScore(scores1));
	    
	  }
	  
	  
	  static int getAverageScore(String[][] arr) {
	   
	    LinkedHashMap<String, Integer> gradeMap = new LinkedHashMap<>();
	    
	    int marksCount = 1;
	    int highestAvg = 0;
	    for(int i=0; i<arr.length; i++) {
	     
	      int marks = Integer.parseInt(arr[i][1]);
	      if(!gradeMap.containsKey(arr[i][0])) {

	    	  gradeMap.put(arr[i][0],  marks);
	    	  marksCount=1;
	      } else {
	        
	        gradeMap.put(arr[i][0], (((gradeMap.get(arr[i][0])*marksCount)+marks)/(marksCount+1)));
	        marksCount++;
	      }
	    }
	    
	    for(String key: gradeMap.keySet()) {
	      
	      System.out.println(key + ":" + gradeMap.get(key));
	      if(highestAvg <= gradeMap.get(key)) {
	        highestAvg = gradeMap.get(key);
	      }
	    }
	    return highestAvg;
	  }
	}
