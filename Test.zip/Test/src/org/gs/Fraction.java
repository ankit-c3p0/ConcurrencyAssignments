package org.gs;

public class Fraction {

	int num;
	int den;

	public Fraction(int num, int den) {
		this.num = num;
		this.den = den;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public int getDen() {
		return den;
	}

	public void setDen(int den) {
		this.den = den;
	}
	
	//calculates GDC/HCF
	static int getGCD(int n1, int n2) {
		
		if(n1 % n2 == 0) 
			return n2;
		return getGCD(n2, n1%n2);
	}
	
	Fraction reduce() {
		int gcd = getGCD(num, den);
		num/=gcd;
		den/=gcd;
		
		return new Fraction(num, den);
	}
	
	Fraction add(Fraction fraction2) {
		
		int denom = den * fraction2.den;
		int numer = (num * fraction2.den) + (fraction2.num * den);
		
		return new Fraction(numer, denom).reduce();
	}
	
	@Override
	public String toString() {
		return num+"\\"+den;
	}
	
	public static void main(String[] args) {
		
		Fraction f1 = new Fraction(1,2);
		System.out.println(f1.add(new Fraction(1, 4)));
	}
}
