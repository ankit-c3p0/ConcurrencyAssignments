package org.gs;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class Ex31_LongestWordFromDictionary {

	static HashSet<String> result = new HashSet<String>();
	static int maxlen = 0;

	public static void main(String[] args) {

		if (doTestPass())
			System.out.println("Test Passed");
		else
			System.out.println("Test Failded");

	}

	static Set<String> longestWord(String letters, Dictionary dict) {

		// find all possible permutation of string

		permute(letters.toCharArray(), 0, dict);

		System.out.println(result.toString());
		return result;

	}

	/**
	 * permutation function
	 * 
	 * @param arr
	 *            string to calculate permutation for
	 * @param startIndex
	 *            starting index
	 * @param len
	 *            end index
	 */
	static void permute(char[] arr, int startIndex, Dictionary dict) {
		if (startIndex == arr.length) {

			String s1 = "";
			for (int i = 0; i < arr.length; i++) {
				s1 = s1 + arr[i];
			}

			// System.out.println(s1);

			// Find All combinations of word
			combination(s1.toCharArray(), dict);
		} else {
			// swapping first and adjacent character
			// ABC-> BAC-> BCA
			// ACB-> CAB-> CBA

			for (int i = startIndex; i < arr.length; i++) {

				arr = swap(arr, startIndex, i);

				permute(arr, startIndex + 1, dict);

				arr = swap(arr, startIndex, i);

			}

		}
	}

	// from each String it will find sub string from beginning i.e abcd- a, ab,
	// abc,
	// abcd
	// also check the Length of each word and store the max len word in set

	private static void combination(char[] charArray, Dictionary dict) {
		String str = "";
		for (int i = 0; i < charArray.length; i++) {
			str = str + charArray[i];
			if (dict.contains(str)) {
				if (str.length() == maxlen) {
					result.add(str);

				} else if (str.length() > maxlen) {
					maxlen = str.length();
					result.clear();
					result.add(str);
				}
			}
		}
	}

	/**
	 * Swap Characters at position
	 * 
	 * @param str
	 *            string value
	 * @param len
	 *            position 1
	 * @param i
	 *            position 2
	 * @return swapped string
	 */
	private static char[] swap(char[] arr, int len, int i) {
		char temp;
		temp = arr[len];
		arr[len] = arr[i];
		arr[i] = temp;

		return arr;
	}

	public static boolean doTestPass() {

		Dictionary dict = new Dictionary(new String[] { "to", "toe", "too",
				"toes", "doe", "dogs", "god", "dog", "book", "banana" });

		boolean result = new HashSet<String>(Arrays.asList("toe", "doe", "dog",
				"god", "too")).equals(longestWord("oegdot", dict));
		result = result
				&& new HashSet<String>(Arrays.asList("toes", "dogs"))
				.equals(longestWord("oegdots", dict));

		// result = result && new HashSet<String>(Arrays.asList("toes",
		// "dogs")).equals(longestWord("osetdg", dict));

		return result;
	}
}

class Dictionary {

	private String[] entries;

	public Dictionary(String[] entries) {

		this.entries = entries;

	}

	public boolean contains(String word) {

		return Arrays.asList(entries).contains(word);

	}
}
