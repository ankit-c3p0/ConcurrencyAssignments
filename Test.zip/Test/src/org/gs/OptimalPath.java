package org.gs;

public class OptimalPath {

	public static void main(String[] args) {

		String[] ip1 = "104.244.4.1".split("\\.");
		String updateStr1 = String.format("%3s.%3s.%1s.%1s", ip1[0], ip1[1], ip1[2], ip1[3]);
		
		System.out.println(updateStr1);
		
		if (doTestPass())
			System.out.println("Test Passed");
		else
			System.out.println("Test Failded");

	}

	static int optimalPath(int[][] grid) {
		// starting is (2,0) and end point is (0,4)

		int[][] path = new int[2 + 1][4 + 1];

		// set start point as it is in path

		path[2][0] = grid[2][0];

		// set all elements in starting point row i.e 2nd row by fetch adjacent
		// previous
		// cell //element

		for (int i = 1; i <= 4; i++) {

			path[2][i] = grid[2][i] + path[2][i - 1];

		}

		// set all elements in starting point column

		for (int i = 1; i >= 0; i--) {

			path[i][0] = grid[i][0] + path[i + 1][0];

		}

		// set rest cell by using 0th column n 2th row , starting from bottom,
		// bcz we
		// are //moving towards north n east.

		for (int i = 2; i > 0; i--) {

			for (int j = 1; j <= 4; j++) {

				path[i - 1][j] = findmax(path[i - 1][j - 1], path[i][j])
						+ grid[i - 1][j];

			}
		}
		System.out.println(path[0][4]);
		return path[0][4];

	}

	static int findmax(int x, int y) {

		return x > y ? x : y;
	}

	public static boolean doTestPass() {

		int[][] input = { { 0, 0, 0, 0, 5 }, { 0, 1, 4, 1, 0 },
				{ 2, 0, 1, 0, 10  } };
		int result = optimalPath(input);

		if (result == 10)
			return true;
		else
			return false;
	}
}




/*0, 0, 0, 0, 5 
0, 1, 4, 1, 0
2, 0, 1, 0, 10 */
