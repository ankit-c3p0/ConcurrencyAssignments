package org.gs;

public class Test {

	static final int max_size = 200;

	public static void main(String[] args) {
		firstUniqueChar("aabbccdef");
	}
	static void firstUniqueChar(String str) {

		char[] charIndex = new char[max_size];
		int countIndex = -1;

		for (int i = 0; i < str.length(); i++) {
			charIndex[str.charAt(i)]++;
			System.out.println(charIndex[str.charAt(i)]++);
		}

		for (int i = 0; i < str.length(); i++) {

			if (charIndex[str.charAt(i)] == 1) {
				countIndex = i;
				break;
			}
		}
		System.out.println(str.charAt(countIndex));
	}
}
