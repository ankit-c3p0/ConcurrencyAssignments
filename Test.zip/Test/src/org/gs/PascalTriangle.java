package org.gs;

public class PascalTriangle {

	static int getElementFromPascalTriangle(int default_rows, int row, int position) {
		
		if(row < position) 
			return 0;
		
		if(row ==0 || row == position) 
			return 1;
		
		return getElementFromPascalTriangle(default_rows, row-1, position) 
				+ getElementFromPascalTriangle(default_rows, row-1, position-1);
	}
	
	public static void main(String[] args) {
		
		int default_rows = 10;
		int row = 5, pos = 2;
		System.out.println(getElementFromPascalTriangle(default_rows, row, pos));
	}
}
