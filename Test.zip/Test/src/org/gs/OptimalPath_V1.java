package org.gs;

public class OptimalPath_V1 {

	static void optimalPath(int[][] grid) {
		
	}
}
