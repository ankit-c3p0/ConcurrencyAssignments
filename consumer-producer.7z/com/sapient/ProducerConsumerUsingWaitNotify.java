package com.sapient;

//Java program to implement solution of producer
//consumer problem.
import java.util.LinkedList;



public class ProducerConsumerUsingWaitNotify
{
 public static void main(String[] args)
                     throws InterruptedException
 {
		final PC1 pc = new PC1();
		
		Thread t1 = new Thread( () -> {
			try{
				pc.produce();
			} catch(InterruptedException ex){
				ex.printStackTrace();
			}
		});
		
		Thread t2 = new Thread( () -> {
			try{
				pc.consume();
			} catch(InterruptedException ex){
				ex.printStackTrace();
			}
		});
		
		t1.start();
		t2.start();
		
	/*	t1.join();
		t2.join();*/
		
	}
	
	public static class PC1 {
		LinkedList<Integer> list = new LinkedList<Integer>();
		int capacity = 2;
		
		public void produce() throws InterruptedException{
			int value = 0;
			while(true){
				synchronized(this){
				
				if(list.size() == capacity){
					wait();
				}
				
				System.out.println("producer produced" + value);
				
				list.add(value++);
				
				notifyAll();
				
				Thread.sleep(1000);
				
				}
			}		
		}
		
		public void consume() throws InterruptedException{
			while(true){
				synchronized(this){
				
				if(list.size() == 0){
					wait();
				}
				
				int value = list.removeFirst();
				
				System.out.println("Consumar consumed" + value);
				
				notifyAll();
				
				Thread.sleep(1000);
				
				}
			}
		}
	}
	
}