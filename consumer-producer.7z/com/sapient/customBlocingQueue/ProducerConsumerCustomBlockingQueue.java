package com.sapient.customBlocingQueue;

public class ProducerConsumerCustomBlockingQueue {
	 
    public static void main(String args[]){
     
     BlockingQueueCustom<Integer> sharedQueue = new LinkedBlockingQueueCustom<Integer>(10); //Creating shared object
    
     ProducerUsingCustomQueue producer=new ProducerUsingCustomQueue(sharedQueue);
     ConsumerUsingCustomQueue consumer=new ConsumerUsingCustomQueue(sharedQueue);
    
     Thread producerThread = new Thread(producer, "ProducerThread");
     Thread consumerThread = new Thread(consumer, "ConsumerThread");
     producerThread.start();
     consumerThread.start();
 
    }
 
}
 
