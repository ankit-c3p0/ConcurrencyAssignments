package com.sapient.customBlocingQueue;


public class ProducerUsingCustomQueue implements Runnable {
	 
    private final BlockingQueueCustom<Integer> sharedQueue;
 
    public ProducerUsingCustomQueue(BlockingQueueCustom<Integer> sharedQueue) {
        this.sharedQueue = sharedQueue;
    }
 
    @Override
    public void run() {
        for(int i=1; i<=10; i++){
         try {
        	 Thread.sleep(1000);
             System.out.println("Produced : " + i);
             //put/produce into sharedQueue.
             sharedQueue.put(i);          
         } catch (InterruptedException ex) {
             
         }
        }
    }
 
}