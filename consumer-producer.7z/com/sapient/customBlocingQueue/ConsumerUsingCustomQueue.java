package com.sapient.customBlocingQueue;

public class ConsumerUsingCustomQueue implements Runnable{
	 
    private BlockingQueueCustom<Integer> sharedQueue;
 
    public ConsumerUsingCustomQueue (BlockingQueueCustom<Integer> sharedQueue) {
        this.sharedQueue = sharedQueue;
    }
 
    @Override
    public void run() {
        while(true){
         try {
        	 Thread.sleep(1000);
           //take/consume from sharedQueue.
             System.out.println("CONSUMED : "+ sharedQueue.take());    
         } catch (InterruptedException ex) {
             
         }
        }
    }
 
 
}
